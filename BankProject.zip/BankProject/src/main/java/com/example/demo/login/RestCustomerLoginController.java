package com.example.demo.login;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin("*")
@RequestMapping("/rest")
public class RestCustomerLoginController {
	
	@Autowired
	CustomerLoginDBdao customer;

	@GetMapping("/customer/{login_id}/{pwd}") 
	public Map<String, String> isValidCredentials(@PathVariable int login_id,@PathVariable String pwd)
	{
		HashMap<String,String> hm=new HashMap<>();
if(customer.existsById(login_id)) {
	Optional<Customer_Login> c=customer.findById(login_id);
	Customer_Login cust=c.get();
	Date date= new Date();
	 long time = date.getTime();
	Timestamp ts = new Timestamp(time);
	if(cust.getPwd().equals(pwd)) {
		hm.put("response", "Success");
		hm.put("timestamp", ts+"");
		  return hm;
	}
}
	hm.put("response", "Failure");
	  return hm;
	}

	@PutMapping("/update")
	public Map<String, String> updateEmployee(@RequestBody Customer_Login cl)
	{
		if(customer.existsById(cl.getLogin_id()))
		{
		customer.save(cl);
		return Collections.singletonMap("response", "Updated!");
		}
		return Collections.singletonMap("response","Invalid_Id");
		
	}

	

}