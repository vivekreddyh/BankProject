package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Customer_Account;

public interface Customer_Account_Dao extends JpaRepository<Customer_Account, String>{

}
