package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Customer_Account {
	@Id
	String acc_no;
	String acc_type;
	@JoinColumn
	int cust_id;
	double amount;
	String ifsc_code;
	String acc_status;
	public Customer_Account() {
		// TODO Auto-generated constructor stub
	}
	public Customer_Account(String acc_no, String acc_type, int cust_id, double amount, String ifsc_code,
			String acc_status) {
		super();
		this.acc_no = acc_no;
		this.acc_type = acc_type;
		this.cust_id = cust_id;
		this.amount = amount;
		this.ifsc_code = ifsc_code;
		this.acc_status = acc_status;
	}

	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getIfsc_code() {
		return ifsc_code;
	}
	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}
	public String getAcc_status() {
		return acc_status;
	}
	public void setAcc_status(String acc_status) {
		this.acc_status = acc_status;
	}
	@Override
	public String toString() {
		return "Customer_Account [acc_no=" + acc_no + ", acc_type=" + acc_type + ", cust_id=" + cust_id + ", amount="
				+ amount + ", ifsc_code=" + ifsc_code + ", acc_status=" + acc_status + "]";
	}

	
}
