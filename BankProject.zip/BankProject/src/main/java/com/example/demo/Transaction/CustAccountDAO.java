package com.example.demo.Transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CustAccountDAO extends JpaRepository<Customer_account, String>{

	@Query("from Customer_account where cust_id = ?1")
	public List<Customer_account> findByAcc(int cust_id);
	
	  @Query("from Customer_transaction where fromacc = ?1 order by tid desc") 
	  public List<Customer_transaction> getLastTenTransactions(String fromacc, int rows);
}
