package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Customer_Details;


public interface Customer_Details_Dao extends JpaRepository<Customer_Details,Integer> {

}