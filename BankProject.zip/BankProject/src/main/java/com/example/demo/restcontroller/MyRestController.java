package com.example.demo.restcontroller;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;



import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Customer_Account;
import com.example.demo.Customer_Details;
import com.example.demo.Customer_Login;
import com.example.demo.Customer_Registration;
import com.example.demo.registration;
import com.example.demo.dao.Customer_Account_Dao;
import com.example.demo.dao.Customer_Details_Dao;
import com.example.demo.dao.Customer_Login_Dao;
import com.example.demo.dao.RegisDBDao;
@CrossOrigin("*")
@RestController
@RequestMapping("/webs")
public class MyRestController {
	@Autowired
	RegisDBDao dao;
	@Autowired
	Customer_Account_Dao dao1;
	@Autowired
	Customer_Details_Dao detailsdbo;

	@RequestMapping("/hi" )
	public Map<String, String> hi() {
		return Collections.singletonMap("response", "hi");
	}
	
	@GetMapping("/registrations")
	public List<registration> getAllDetails() {
		return dao.findAll();
	}
	
	@GetMapping("/registrations/{account_no}")
	public Optional<registration> getAllById(@PathVariable String account_no) {
	
		return dao.findById(account_no);
	}
	
	@PostMapping("/registrations")
	public Map<String,String> createDetails(@RequestBody registration r){
		HashMap<String,String> hm=new HashMap<>();
		List<registration> regis=dao.findAll();
		int cid=0,counter=0;
		long acc=0;
		for(registration regisobj:regis) {
			if(r.getPan_no().equals(regisobj.getPan_no())) {
				r.setCustomer_id(regisobj.getCustomer_id());counter++;
				break;
			}
			if(cid<regisobj.getCustomer_id()) {
				cid=regisobj.getCustomer_id();
			}
			if(acc<Long.parseLong(regisobj.getAccount_no())) {
				acc=Long.parseLong(regisobj.getAccount_no());
			}
		}acc++;
		r.setAccount_no(acc+"");
		
		if(counter==0) {
			r.setCustomer_id(cid+1);
		}
		if(r.getAccount_status()=="") {
			r.setAccount_status("Active");
		}
		if(dao.existsById(r.getAccount_no())){
			hm.put("response", "Failure");
			return hm;
		}
		dao.save(r); 	 	
		hm.put("response", "Success");
	
		return hm;
	}
	
	@PutMapping("/registrations")
	public Map<String, String> updateDetails(@RequestBody registration reg){
		
		HashMap<String,String> hm=new HashMap<>();
		if(dao.existsById(reg.getAccount_no())){
			dao.save(reg);
			Customer_Details custDet = new Customer_Details();
			custDet.setCust_id(reg.getCustomer_id());
			custDet.setCust_firstname(reg.getFirstname());
			custDet.setCust_middlename(reg.getMiddlename());
			custDet.setCust_lastname(reg.getLastname());
			custDet.setPhno(reg.getPhone_no());
			custDet.setEmail(reg.getEmail_id());
			custDet.setCust_address(reg.getAddress());
			custDet.setCust_pan(reg.getPan_no());
			if(detailsdbo.existsById(reg.getCustomer_id())) {
				detailsdbo.save(custDet);		
			}
			Customer_Account custAcc = new Customer_Account();;
			custAcc.setAcc_no(reg.getAccount_no());
			custAcc.setAcc_type(reg.getAccount_type());
			custAcc.setAmount(reg.getBalance());
			custAcc.setCust_id(reg.getCustomer_id());
			custAcc.setIfsc_code(reg.getIfsc_code());
			custAcc.setAcc_status(reg.getAccount_status());
			if(dao1.existsById(reg.getAccount_no())) {
				dao1.save(custAcc);
			}
			hm.put("response", "Success");
			return hm;
		}
		hm.put("responce", "Failure");
		return hm;
	}	
	
	@DeleteMapping("/registrations/{account_no}")
	public Map<String, String> deleteDetails(@PathVariable String account_no){
		HashMap<String,String> hm=new HashMap<>();
		if(dao.existsById(account_no)){
			Optional<registration> optreg=dao.findById(account_no);
			registration r=optreg.get();
			dao.deleteById(account_no);
			if(detailsdbo.existsById(r.getCustomer_id())) {
				detailsdbo.deleteById(r.getCustomer_id());
			}
			if(dao1.existsById(r.getAccount_no())) {
				dao1.deleteById(r.getAccount_no());
			}
			hm.put("response", "Success");
			return hm;
		}
		hm.put("response", "Failure");
		return hm;
	}	
}

@CrossOrigin("*")
@RestController
@RequestMapping("/bank")
class MyRestControllerOfCustDetails {
	@Autowired
    Customer_Details_Dao dao;
	@GetMapping(value="hi")
	public String sayHi() {
		return "Hello World!";
	}
	
	@GetMapping("/CustDetails")
    public List<Customer_Details> getDetails() {
   	 return dao.findAll();
    }
    
	@GetMapping("/CustDetails/{cust_id}")
    public Optional<Customer_Details> getDetailsById(@PathVariable int cust_id) {
   	 return dao.findById(cust_id);
    }
	
	@PutMapping("/CustDetails")
	public String updateDetails(@RequestBody Customer_Details c) {
	  int id = c.getCust_id();
	   if(dao.existsById(id)) {
		   dao.save(c);
		   return "Successfully updated";
	   }	  
	   else
		   return "Cannot find record";
    }
	
	@PostMapping("/CustDetails")
	public String addDetails(@RequestBody Customer_Details c) {
		int id=c.getCust_id();
		if(dao.existsById(id)) {
			   return "Record already exists";
		   }	  
		   else {
			   dao.save(c);
			   return "Sccessfully added";
		   }
			   
    }
	
	@DeleteMapping("/CustDetails/{id}")
	public String deleteBook(@PathVariable("id") Integer id) {
		if(dao.existsById(id)) {
			dao.deleteById(id);
			return "Successfully Deleted record";
		}
		else {
			return "Record not found";
		}
	}
}
@CrossOrigin("*")
@RestController
@RequestMapping("/acct")
class MyRestControllerOfCustAccount {
	@Autowired
	Customer_Account_Dao dao;
	
	@GetMapping(value="hi")
	public String sayHi() {
		return "Hello World! from acct";
	}
	
	@GetMapping("/CustAcct")
    public List<Customer_Account> getDetails() {
   	 return dao.findAll();
    }
    
	@GetMapping("/CustAcct/{acc_no}")
    public Optional<Customer_Account> getDetailsById(@PathVariable String acc_no) {
   	 return dao.findById(acc_no);
    }
	
	@PutMapping("/CustAcct")
	public String updateDetails(@RequestBody Customer_Account c) {
		String id = c.getAcc_no();
	   if(dao.existsById(id)) {
		   dao.save(c);
		   return "Successfully updated";
	   }	  
	   else
		   return "Cannot find record";
    }
	
	@PostMapping("/CustAcct")
	public String addDetails(@RequestBody Customer_Account c) {
		System.out.println(c);
		String id=c.getAcc_no();
		if(dao.existsById(id)) {
			   return "Record already exists";
		   }	  
		   else {
			   dao.save(c);
			   return "Sccessfully added";
		   }
			   
    }
	
	@DeleteMapping("/CustAcct/{acc_no}")
	public String deleteBook(@PathVariable String acc_no) {
		if(dao.existsById(acc_no)) {
			dao.deleteById(acc_no);
			return "Successfully Deleted record";
		}
		else {
			return "Record not found";
		}
	}
}

@CrossOrigin("*")
@RestController
@RequestMapping("/regis")
class MyRestControllerOfCustRegistration {
	@Autowired
	Customer_Account_Dao dao;
	@Autowired
	Customer_Details_Dao detailsdbo;
	@Autowired
	RegisDBDao regisdbo;
	
	@GetMapping("/hi")
	public Map<String, String> hi() {
		return Collections.singletonMap("response", "Hello World! from regis");
	}
	@GetMapping("/elements")
	public String elements() {
		return "only pushing is possible through this URL";
	}
	
	@PostMapping("/custregis")
	public Map<String, String> addDetails(@RequestBody Customer_Registration c) {
		
		String acc_no=c.getAcc_no();
		String pan_no=c.getPan_no();
		Optional<registration> optreg;
		if(regisdbo.existsById(acc_no)) {
			optreg=regisdbo.findById(acc_no);
			registration reg=optreg.get();
			if(!reg.getPan_no().equals(pan_no)) {
			 return Collections.singletonMap("response","Pan number is incorrect");
			}
			if(detailsdbo.existsById(reg.getCustomer_id())) {
				
				return Collections.singletonMap("response","Internet banking account already exists with this pannumber");				
			}
			else {
				Customer_Details custDet = new Customer_Details();
				custDet.setCust_id(reg.getCustomer_id());
				custDet.setCust_firstname(reg.getFirstname());
				custDet.setCust_middlename(reg.getMiddlename());
				custDet.setCust_lastname(reg.getLastname());
				custDet.setPhno(reg.getPhone_no());
				custDet.setEmail(reg.getEmail_id());
				custDet.setCust_address(reg.getAddress());
				custDet.setCust_pan(reg.getPan_no());
				detailsdbo.save(custDet);
				Customer_Account custAcc = new Customer_Account();;
				custAcc.setAcc_no(reg.getAccount_no());
				custAcc.setAcc_type(reg.getAccount_type());
				custAcc.setAmount(reg.getBalance());
				custAcc.setCust_id(reg.getCustomer_id());
				custAcc.setIfsc_code(reg.getIfsc_code());
				custAcc.setAcc_status(reg.getAccount_status());
				dao.save(custAcc);
				HashMap<String,String> hm=new HashMap<>();
				hm.put("response","Success");
				hm.put("custid",reg.getCustomer_id()+"");
				return hm;
			}
		}
		else {
			return Collections.singletonMap("response","account is not opened");
		}	   
    }

}

@RestController
@CrossOrigin("*")
@RequestMapping("/details")
 class LoginDetails {
	@Autowired
	Customer_Login_Dao dao;
	
	@PostMapping("/login")
	public Map<String,String> setDetails(@RequestBody Customer_Login clogin){
		HashMap<String,String> hm=new HashMap<>();
		if(!dao.existsById(clogin.getLogin_id())) {
			Date date= new Date();
			 long time = date.getTime();
			Timestamp ts = new Timestamp(time);
			clogin.setLast_login_time(ts);
			dao.save(clogin);
			hm.put("response", "Success");
			return hm;
		}
		hm.put("response", "Failure");
		return hm;
	}
	@GetMapping("/login")
	public List<Customer_Login> getdetails(){
		return dao.findAll();
	} 
 }

class PasswordEncode{
	public static String encoder(String pwd) {
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		String hashedPassword="";
		hashedPassword=encoder.encode(pwd);
		return hashedPassword;
	}
}
