package com.example.demo.Transaction;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer_account {
	@Id
	private String acc_no;
	private String acc_type;
	private int cust_id;
	private double amount;
	private String ifsc_code;
	public String getAcc_no() {
		return acc_no;
	}
	
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getIfsc_code() {
		return ifsc_code;
	}
	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}
	
	@Override
	public String toString() {
		return "Customer_account [acc_no=" + acc_no + ", acc_type=" + acc_type + ", cust_id=" + cust_id + ", amount="
				+ amount + ", ifsc_code=" + ifsc_code + "]";
	}
}
